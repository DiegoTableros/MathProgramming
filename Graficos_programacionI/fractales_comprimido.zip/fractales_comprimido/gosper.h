#ifndef _MI_GOSPER_H_
#define _MI_GOSPER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "logo.h"

int iniciaGosper(int n, double l, double x, double y, LOGO *tortuga);
int dibujaGosper(void);

#ifdef __cplusplus
}
#endif

#endif
