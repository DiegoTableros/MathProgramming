#ifndef _MI_POLYGON_H_
#define _MI_POLYGON_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "logo.h"

int iniciaPolygon(double size, double angle, double l, double x, double y, LOGO *tortuga);
int dibujaPolygon(void);

#ifdef __cplusplus
}
#endif

#endif
