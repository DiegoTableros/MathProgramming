#ifndef _MI_TRIANGLES_H_
#define _MI_TRIANGLES_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "logo.h"

int iniciaTriangles(int n, double l, double x, double y, LOGO *tortuga);
int dibujaTriangles(void);

#ifdef __cplusplus
}
#endif

#endif
